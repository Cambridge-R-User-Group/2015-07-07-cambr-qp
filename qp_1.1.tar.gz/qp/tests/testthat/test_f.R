test_that("Test f function", {
              expect_null(f())
              expect_message(f(), "Hello CambR")
          })
