##' The description of the function comes here.
##'
##' @title A friendly message
##' @return \code{NULL}; used for its side effect.
##' @author Laurent Gatto
f <- function() message("Hello CambR")
